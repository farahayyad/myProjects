/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package github;

import java.util.Scanner;

/**
 *
 * @author farahayyad
 */
public class connect4Game {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
        char[][] gameBoard = new char[6][7];
        int redRow, redCol, yellowRow, yellowCol;
        String winner="NO ONE";
        
        fillBoard(gameBoard);
        
        while(true){
            printBoard(gameBoard);
            
            do{
                System.out.println("Red player, where would you like to enter your disc? ");
                redRow=input.nextInt();
                redCol=input.nextInt();
            }
            while(!(validation(gameBoard, redRow, redCol)));{//do-while loop will keep asking player for input until they enter a valid input/ spot
                gameBoard[redRow][redCol]='R';
            }
            
            do{
                System.out.println("Yellow player, where would you like to enter your disc? ");
                yellowRow=input.nextInt();
                yellowCol=input.nextInt();
            }
            while(!(validation(gameBoard, yellowRow, yellowCol)));{
                gameBoard[yellowRow][yellowCol]='Y';
            } 
            
            
            if (checkHorizontal(gameBoard, 'R') || checkVertical(gameBoard, 'R') || checkToRightDiagonal(gameBoard, 'R')|| checkToLeftDiagonal(gameBoard, 'R')){
                winner="RED";
                break;
            }
            if (checkHorizontal(gameBoard, 'Y') || checkVertical(gameBoard, 'Y') || checkToRightDiagonal(gameBoard, 'Y') || checkToLeftDiagonal(gameBoard, 'Y')){
                winner="YELLOW";
                break;
            }
        }
        printBoard(gameBoard);
        System.out.println("The game is finished, the winner is: "+winner);
        
    }
    
    public static void printBoard(char[][] arr){//aim: print contents & show players the empty & filled spots
        for(int r=0; r<arr.length; r++){
            for(int c=0; c<arr[0].length; c++)
                System.out.print(arr[r][c]+"\t");
            System.out.println();
        }
    }
    
    public static void fillBoard(char[][] arr){//aim: initialize all spots to 'E' meaning EMPTY
        for(int r=0; r<arr.length; r++){
            for(int c=0; c<arr[0].length; c++)
                arr[r][c]='E';
        }
    }
    
    public static boolean validation(char[][] gameBoard, int row, int col){ 
        //aim: validate the entered location by:
        //1. checking if the spot is empty
        //2. checking if the spot under it is NOT empty
        boolean b=true;
        if(row==5 && gameBoard[row][col]=='E')//this is going to be used for the bottom row only because there is no row under it
            b=true;
        else if ((gameBoard[row][col]!='E') || (gameBoard[row+1][col]=='E'))
            b=false;
        return b;
    }
    
    public static boolean checkHorizontal(char[][] arr, char player){//aim: checking if there are four consecutive spots with the same color horizontally
        int counter=1;
        for(int row=0; row<arr.length; row++){
            for(int col=0; col<arr[0].length-1; col++){
                if((arr[row][col] == player) && (arr[row][col+1] == player)){//this is why we set counter=1 NOT =0, because the condition checks two spots at a time
                    counter++;
                    if(counter>=4)
                        return true;
                }
                else
                    counter=1;//reset counter to 1
            }
        }
        return false;
    }
    
    public static boolean checkVertical(char[][] arr, char player){//aim: checking if there are four consecutive spots vertically
        int counter=1;
        for(int c=0; c<arr[0].length; c++){
            for(int r=0; r<arr.length-1; r++){
                if((arr[r][c] == player) && (arr[r+1][c] == player)){
                    counter++;
                    if(counter>=4)
                        return true;
                }
                else
                    counter=1;
            }
        }
        return false;
    }
    
    public static boolean checkToRightDiagonal(char[][] arr, char player){//aim: check if there are 4 consecutive spots filled with the same color diagonally
        for(int r = 3; r < arr.length; r++){
            for(int c = 0; c < arr[0].length - 3; c++){
                if (arr[r][c] == player && arr[r-1][c+1] == player && arr[r-2][c+2] == player && arr[r-3][c+3] == player){
                        return true;
                }
            }
        }
        return false;
    }

    public static boolean checkToLeftDiagonal(char[][] arr, char player){
        for(int r = 0; r < arr.length - 3; r++){
            for(int c = 0; c < arr[0].length - 3; c++){
                if (arr[r][c] == player && arr[r+1][c+1] == player && arr[r+2][c+2] == player && arr[r+3][c+3] == player){
                        return true;
                }
            }
        }
	return false;
    }
}

